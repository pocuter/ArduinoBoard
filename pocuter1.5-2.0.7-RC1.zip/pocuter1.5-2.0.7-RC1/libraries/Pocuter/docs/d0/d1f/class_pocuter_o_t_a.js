var class_pocuter_o_t_a =
[
    [ "OTAERROR", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3", [
      [ "OTAERROR_OK", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a0aa619870c61151066abffa02062b47f", null ],
      [ "OTAERROR_PATITION_NOT_AVAILABLE", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a2a1fe0754747708105124a044635ec94", null ],
      [ "OTAERROR_PATITION_IN_USE", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3ab96f3af3dddf616fbf7c2757e9671ad4", null ],
      [ "OTAERROR_FILE_NOT_FOUND", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a43244cfe27277cfc0a7e0bc72662b29e", null ],
      [ "OTAERROR_NO_SD_CARD", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3adde1743b8ebd0b0ab790fc54ef0bc628", null ],
      [ "OTAERROR_FLASHING_FAILED", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a61008c290cf00ffeb8777193107a8bb6", null ],
      [ "OTAERROR_MORE_STEPS", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a25d73d94553e4a90e9f6ee3f3a45ba11", null ],
      [ "OTAERROR_APP_READ_ERROR", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3ae96ceeeadcb826f8eb4d12d3ad708dd4", null ],
      [ "OTAERROR_UNKNOWN", "d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3ade1731d4e4c8092c07d571c4eeacf5eb", null ]
    ] ],
    [ "POCUTER_PARTITION", "d0/d1f/class_pocuter_o_t_a.html#a2902dbffc3df5819fac8dda21812ce1b", [
      [ "PART_APPLOADER", "d0/d1f/class_pocuter_o_t_a.html#a2902dbffc3df5819fac8dda21812ce1ba52ee7a978853d7e2cfe63eefc93c2b5b", null ],
      [ "PART_APP1", "d0/d1f/class_pocuter_o_t_a.html#a2902dbffc3df5819fac8dda21812ce1bac96caf5ddec1b731aae7e815c2c36448", null ],
      [ "PART_UNKNOWN", "d0/d1f/class_pocuter_o_t_a.html#a2902dbffc3df5819fac8dda21812ce1ba2720766daa2de5c457a50dd8f4a01272", null ]
    ] ],
    [ "bootPartition", "d0/d1f/class_pocuter_o_t_a.html#a04e285de2d9ca7486d0f9a266d27ad55", null ],
    [ "flashFromSDCard", "d0/d1f/class_pocuter_o_t_a.html#a3e2836d888c79a77f937cd131649c634", null ],
    [ "forceBootloaderToReflashApp", "d0/d1f/class_pocuter_o_t_a.html#a03e231fe9b396f4de0b9109253cd0f44", null ],
    [ "getApps", "d0/d1f/class_pocuter_o_t_a.html#a4702e596c493f0842ae9fb0c32ddda76", null ],
    [ "getAppsCount", "d0/d1f/class_pocuter_o_t_a.html#a850deb079610212dd7be4741c0039c01", null ],
    [ "getAppVersion", "d0/d1f/class_pocuter_o_t_a.html#abdaded12146e88651609e9bb32d56833", null ],
    [ "getCurrentPartition", "d0/d1f/class_pocuter_o_t_a.html#a7c08f736810f2306b507b868de277242", null ],
    [ "restart", "d0/d1f/class_pocuter_o_t_a.html#afb45eb6c899a07a5a53e612fd305d1a7", null ],
    [ "setNextAppID", "d0/d1f/class_pocuter_o_t_a.html#aac7b3d327e6399ec6ab11d59aea94820", null ],
    [ "verifyPartition", "d0/d1f/class_pocuter_o_t_a.html#a7c089b9d31ca5914e6d4ab42a7c196ae", null ]
];
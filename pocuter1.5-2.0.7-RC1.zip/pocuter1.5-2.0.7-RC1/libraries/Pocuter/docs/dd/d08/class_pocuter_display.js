var class_pocuter_display =
[
    [ "BUFFER_MODE", "dd/d08/class_pocuter_display.html#a82acc006080c021c32e9f8235788e7d9", [
      [ "BUFFER_MODE_NO_BUFFER", "dd/d08/class_pocuter_display.html#a82acc006080c021c32e9f8235788e7d9a1e59a591595e83710dcd3ce76aad8ab5", null ],
      [ "BUFFER_MODE_DOUBLE_BUFFER", "dd/d08/class_pocuter_display.html#a82acc006080c021c32e9f8235788e7d9a1a18ef1861c204cd04a1493afc602ec3", null ]
    ] ],
    [ "clearScreen", "dd/d08/class_pocuter_display.html#a9595ebbcc7869ba6724779397b756762", null ],
    [ "clearWindow", "dd/d08/class_pocuter_display.html#a2e3e518ef962d117193e7acf4d8a55e4", null ],
    [ "continuousScreenUpdate", "dd/d08/class_pocuter_display.html#ac8a0b4c8cc31642c44f35bf4906a394e", null ],
    [ "doSleep", "dd/d08/class_pocuter_display.html#a67749d97a9a003b92b557d512e3b9648", null ],
    [ "doWakeUp", "dd/d08/class_pocuter_display.html#a7ae2bdad19a869e455571c83fc553cf6", null ],
    [ "draw16BitScanLine", "dd/d08/class_pocuter_display.html#ad0d7a9f8adcdf31f595de5ffadcd367a", null ],
    [ "drawLine", "dd/d08/class_pocuter_display.html#ac2d7a21322ae8d17ce9d8e0a8f4e720a", null ],
    [ "drawRectangle", "dd/d08/class_pocuter_display.html#ab97a8f0578f793d9de40bf94e657d5c0", null ],
    [ "drawScanLine", "dd/d08/class_pocuter_display.html#a34c067f9a3ba4560e477565a0b5800da", null ],
    [ "getBufferMode", "dd/d08/class_pocuter_display.html#a77cd497f966260c7b529cff203d23063", null ],
    [ "getDisplaySize", "dd/d08/class_pocuter_display.html#a52f20492fc445ec60c65d3b00d9a4fcb", null ],
    [ "setBrightness", "dd/d08/class_pocuter_display.html#a021a8daaa8726d3de60944f47261d353", null ],
    [ "setPixel", "dd/d08/class_pocuter_display.html#adb716d140815cb23c370a8cd2de15653", null ],
    [ "updateScreen", "dd/d08/class_pocuter_display.html#a79c629c35320c2e4147bfaac8741484c", null ]
];
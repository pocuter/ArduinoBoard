var struct_pocuter_time_1_1pocuter_timezone =
[
    [ "name", "dc/d6c/struct_pocuter_time_1_1pocuter_timezone.html#a9204b4a72075e715cb6e87199d6e4a99", null ],
    [ "timezoneString", "dc/d6c/struct_pocuter_time_1_1pocuter_timezone.html#ad1a3771f8a89026f201b76e9a535d1cb", null ]
];
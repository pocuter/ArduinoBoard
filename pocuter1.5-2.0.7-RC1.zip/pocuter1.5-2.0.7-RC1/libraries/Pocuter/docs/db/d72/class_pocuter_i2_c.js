var class_pocuter_i2_c =
[
    [ "read", "db/d72/class_pocuter_i2_c.html#a2af41be99db47af35ceb0db98654d64a", null ],
    [ "read", "db/d72/class_pocuter_i2_c.html#ac98809cf11bd3efc0c94e72fbdd5e8cd", null ],
    [ "write", "db/d72/class_pocuter_i2_c.html#ab3fa81d2d0828d42ecc4c77a7e0073e4", null ],
    [ "write", "db/d72/class_pocuter_i2_c.html#a260c293593ac1cbf2261b2432966dced", null ]
];
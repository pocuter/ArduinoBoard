var class_pocuter_light_sensor =
[
    [ "lightEventHandler", "d1/d48/class_pocuter_light_sensor.html#ac061454cec5b2997ff1865809e396eb1", null ],
    [ "LIGHTERROR", "d1/d48/class_pocuter_light_sensor.html#a315729d520e84c8ec341e3425ca553e1", [
      [ "LIGHTERROR_OK", "d1/d48/class_pocuter_light_sensor.html#a315729d520e84c8ec341e3425ca553e1a28a56673a5e3a701a59fb4077eb39e2f", null ],
      [ "LIGHTERROR_UNKNOWN", "d1/d48/class_pocuter_light_sensor.html#a315729d520e84c8ec341e3425ca553e1a76aca07fae1b242744945543dbabe082", null ]
    ] ],
    [ "LIGHTEVENT", "d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfe", [
      [ "LIGHT_ABOVE_LIMIT", "d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfeaffcb7da3eff7f2c5710e3b6e1c4769d2", null ],
      [ "LIGHT_UNDER_LIMIT", "d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfea7caf907a1e44c7a9e4e3d512391b016d", null ],
      [ "LIGHT_TOLLERANCE_CHANGED", "d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfeadfe213d8eba2d36dbf7955e754727b35", null ]
    ] ],
    [ "getValue", "d1/d48/class_pocuter_light_sensor.html#abca771cb2c489e2322ccc555fdd63afa", null ],
    [ "registerEventHandler", "d1/d48/class_pocuter_light_sensor.html#ab81f405a9f8ceea4cd3f67044e860d81", null ],
    [ "unregisterEventHandler", "d1/d48/class_pocuter_light_sensor.html#ae84478425d18568cabf5cabbf2f6204c", null ]
];
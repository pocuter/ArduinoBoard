var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "Pocuter.cpp", "dc/d70/_pocuter_8cpp.html", null ],
    [ "Pocuter.h", "db/ddf/_pocuter_8h.html", "db/ddf/_pocuter_8h" ]
];
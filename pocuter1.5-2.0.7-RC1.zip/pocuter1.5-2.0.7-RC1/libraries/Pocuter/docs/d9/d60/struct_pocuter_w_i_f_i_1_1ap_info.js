var struct_pocuter_w_i_f_i_1_1ap_info =
[
    [ "authMode", "d9/d60/struct_pocuter_w_i_f_i_1_1ap_info.html#a74eae0eb8e7653f70545f0f8771f4cef", null ],
    [ "bssid", "d9/d60/struct_pocuter_w_i_f_i_1_1ap_info.html#aae8f065f6f48e8239ebb2d7b8ce4d207", null ],
    [ "channel", "d9/d60/struct_pocuter_w_i_f_i_1_1ap_info.html#a3fbacf0338673b4531d1cc40ccea39a3", null ],
    [ "signalStrength", "d9/d60/struct_pocuter_w_i_f_i_1_1ap_info.html#a9b827e0d4cccb89aad48c711f3d3ac34", null ],
    [ "ssid", "d9/d60/struct_pocuter_w_i_f_i_1_1ap_info.html#afb0dcdc0e1921340ff51d5bc8f00fbb7", null ]
];
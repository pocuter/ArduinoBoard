var searchData=
[
  ['deep_5fsleep_5fmemory_679',['DEEP_SLEEP_MEMORY',['../db/ddf/_pocuter_8h.html#a1be229eac10b327b68e1b8c1f846ad9c',1,'Pocuter.h']]]
];

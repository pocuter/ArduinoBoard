var searchData=
[
  ['readme_204',['README',['../d3/dcc/md__r_e_a_d_m_e.html',1,'']]],
  ['read_205',['read',['../db/d72/class_pocuter_i2_c.html#ac98809cf11bd3efc0c94e72fbdd5e8cd',1,'PocuterI2C::read(uint8_t i2c_addr, uint8_t i2c_reg, uint8_t *data_rd, size_t size)=0'],['../db/d72/class_pocuter_i2_c.html#a2af41be99db47af35ceb0db98654d64a',1,'PocuterI2C::read(uint8_t i2c_addr, uint8_t i2c_reg)=0']]],
  ['readme_2emd_206',['README.md',['../d9/dd6/_r_e_a_d_m_e_8md.html',1,'']]],
  ['reduction_5flevel_5fhight_207',['REDUCTION_LEVEL_HIGHT',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eab9c3f0edb28268bc99f3df8a6874dc1c',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fmedium_208',['REDUCTION_LEVEL_MEDIUM',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090ea35af993c4995e6d1c65ea3fe3efecf35',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fnone_209',['REDUCTION_LEVEL_NONE',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eafc15430687136edc8feee88102ad0aae',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fraw_210',['REDUCTION_LEVEL_RAW',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eacd72f0c21093c82683d3c9ef4d57f279',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fsmall_211',['REDUCTION_LEVEL_SMALL',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090ea4c2da3650adb394ae536ef64bfe8bfcc',1,'PocuterMicrophone']]],
  ['registereventhandler_212',['registerEventHandler',['../df/dad/class_pocuter_accelerometer.html#a80c972f6430295acfb9ce98961cff6ac',1,'PocuterAccelerometer::registerEventHandler()'],['../df/d44/class_pocuter_buttons.html#a5df77dd63f6b3bf8df71f96db9890836',1,'PocuterButtons::registerEventHandler()'],['../d1/d48/class_pocuter_light_sensor.html#ab81f405a9f8ceea4cd3f67044e860d81',1,'PocuterLightSensor::registerEventHandler()'],['../d5/d3f/class_pocuter_microphone.html#aae1bc783759a21dc821e1a4c4c66a119',1,'PocuterMicrophone::registerEventHandler()'],['../d4/d9b/class_pocuter_ports.html#ae064397d79fe38c806bac1e32a827c0d',1,'PocuterPorts::registerEventHandler()'],['../d4/d00/class_pocuter_sleep.html#a62d16d34aac33f2806419606dc75a66f',1,'PocuterSleep::registerEventHandler()'],['../da/d85/class_pocuter_w_i_f_i.html#ab0dc89c32098fb8ffb90bbfb40c3f30e',1,'PocuterWIFI::registerEventHandler()']]],
  ['restart_213',['restart',['../d0/d1f/class_pocuter_o_t_a.html#afb45eb6c899a07a5a53e612fd305d1a7',1,'PocuterOTA']]],
  ['resumeinterrupthandler_214',['resumeInterruptHandler',['../df/dad/class_pocuter_accelerometer.html#aa0bd243e76fae0653be7e5018f9ce435',1,'PocuterAccelerometer::resumeInterruptHandler()'],['../d4/d9b/class_pocuter_ports.html#a28209fd33fa8eb0c20712a91681d5376',1,'PocuterPorts::resumeInterruptHandler()']]],
  ['rgbled_215',['RGBled',['../d6/d2a/class_r_g_bled.html',1,'RGBled'],['../d2/dca/class_pocuter.html#ab4b79dcd183b9f5d57cb351f7b6c50e5',1,'Pocuter::RGBLed()']]],
  ['rgbled_2eh_216',['RGBled.h',['../d1/d8f/_r_g_bled_8h.html',1,'']]]
];

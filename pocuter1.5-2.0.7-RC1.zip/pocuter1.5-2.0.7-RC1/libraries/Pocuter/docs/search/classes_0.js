var searchData=
[
  ['apinfo_339',['apInfo',['../d9/d60/struct_pocuter_w_i_f_i_1_1ap_info.html',1,'PocuterWIFI']]]
];

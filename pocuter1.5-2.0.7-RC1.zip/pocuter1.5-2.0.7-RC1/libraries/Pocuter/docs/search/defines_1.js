var searchData=
[
  ['time_5fzones_5fcount_680',['TIME_ZONES_COUNT',['../df/d04/_pocuter_time_8h.html#a05b5f2bd02ccd175608c7af471a2a0a8',1,'TIME_ZONES_COUNT():&#160;PocuterTime.h'],['../df/d04/_pocuter_time_8h.html#a05b5f2bd02ccd175608c7af471a2a0a8',1,'TIME_ZONES_COUNT():&#160;PocuterTime.h']]]
];

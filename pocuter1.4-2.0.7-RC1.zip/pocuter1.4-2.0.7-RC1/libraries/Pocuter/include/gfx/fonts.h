#ifndef _GFONTS_H_
#define _GFONTS_H_

#include "GFX.h"

extern Font psFont5x3;
extern Font psFont5x4;
extern Font psFont6x4;
extern Font psFont7x4;
extern Font psFont7x5;

#endif


var annotated_dup =
[
    [ "Pocuter", "d2/dca/class_pocuter.html", "d2/dca/class_pocuter" ],
    [ "PocuterAccelerometer", "df/dad/class_pocuter_accelerometer.html", "df/dad/class_pocuter_accelerometer" ],
    [ "PocuterButtons", "df/d44/class_pocuter_buttons.html", "df/d44/class_pocuter_buttons" ],
    [ "PocuterConfig", "d4/d0f/class_pocuter_config.html", "d4/d0f/class_pocuter_config" ],
    [ "PocuterDisplay", "dd/d08/class_pocuter_display.html", "dd/d08/class_pocuter_display" ],
    [ "PocuterHMAC", "d4/d79/class_pocuter_h_m_a_c.html", "d4/d79/class_pocuter_h_m_a_c" ],
    [ "PocuterHTTP", "d6/dc4/class_pocuter_h_t_t_p.html", "d6/dc4/class_pocuter_h_t_t_p" ],
    [ "PocuterI2C", "db/d72/class_pocuter_i2_c.html", "db/d72/class_pocuter_i2_c" ],
    [ "PocuterLightSensor", "d1/d48/class_pocuter_light_sensor.html", "d1/d48/class_pocuter_light_sensor" ],
    [ "PocuterMicrophone", "d5/d3f/class_pocuter_microphone.html", "d5/d3f/class_pocuter_microphone" ],
    [ "PocuterOTA", "d0/d1f/class_pocuter_o_t_a.html", "d0/d1f/class_pocuter_o_t_a" ],
    [ "PocuterPorts", "d4/d9b/class_pocuter_ports.html", "d4/d9b/class_pocuter_ports" ],
    [ "PocuterSDCard", "d1/dea/class_pocuter_s_d_card.html", "d1/dea/class_pocuter_s_d_card" ],
    [ "PocuterServer", "dd/d45/class_pocuter_server.html", "dd/d45/class_pocuter_server" ],
    [ "PocuterSleep", "d4/d00/class_pocuter_sleep.html", "d4/d00/class_pocuter_sleep" ],
    [ "PocuterTime", "d8/dac/class_pocuter_time.html", "d8/dac/class_pocuter_time" ],
    [ "PocuterWIFI", "da/d85/class_pocuter_w_i_f_i.html", "da/d85/class_pocuter_w_i_f_i" ],
    [ "RGBled", "d6/d2a/class_r_g_bled.html", "d6/d2a/class_r_g_bled" ]
];
var searchData=
[
  ['deep_5fsleep_5fmemory_38',['DEEP_SLEEP_MEMORY',['../db/ddf/_pocuter_8h.html#a1be229eac10b327b68e1b8c1f846ad9c',1,'Pocuter.h']]],
  ['deinitport_39',['deinitPort',['../d4/d9b/class_pocuter_ports.html#ab446fdd604a3078fcda1092411febd5e',1,'PocuterPorts']]],
  ['del_40',['del',['../d4/d0f/class_pocuter_config.html#a00f3c2d99a0456ae71b73500f6c1d157',1,'PocuterConfig']]],
  ['display_41',['Display',['../d2/dca/class_pocuter.html#a9375a4776719e1aa2306aa4dc249f6ff',1,'Pocuter']]],
  ['dosleep_42',['doSleep',['../dd/d08/class_pocuter_display.html#a67749d97a9a003b92b557d512e3b9648',1,'PocuterDisplay']]],
  ['dosleepnow_43',['doSleepNow',['../d4/d00/class_pocuter_sleep.html#a000ee08723e8b6fab4baefcf7085a71c',1,'PocuterSleep']]],
  ['dowakeup_44',['doWakeUp',['../dd/d08/class_pocuter_display.html#a7ae2bdad19a869e455571c83fc553cf6',1,'PocuterDisplay']]],
  ['downloadfile_45',['downloadFile',['../d6/dc4/class_pocuter_h_t_t_p.html#ae8a6ff33381c6c99558d9773d6c10bff',1,'PocuterHTTP']]],
  ['draw16bitscanline_46',['draw16BitScanLine',['../dd/d08/class_pocuter_display.html#ad0d7a9f8adcdf31f595de5ffadcd367a',1,'PocuterDisplay']]],
  ['drawline_47',['drawLine',['../dd/d08/class_pocuter_display.html#ac2d7a21322ae8d17ce9d8e0a8f4e720a',1,'PocuterDisplay']]],
  ['drawrectangle_48',['drawRectangle',['../dd/d08/class_pocuter_display.html#ab97a8f0578f793d9de40bf94e657d5c0',1,'PocuterDisplay']]],
  ['drawscanline_49',['drawScanLine',['../dd/d08/class_pocuter_display.html#a34c067f9a3ba4560e477565a0b5800da',1,'PocuterDisplay']]]
];

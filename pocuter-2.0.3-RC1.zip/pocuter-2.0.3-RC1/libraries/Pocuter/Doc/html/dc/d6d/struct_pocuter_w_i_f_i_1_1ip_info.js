var struct_pocuter_w_i_f_i_1_1ip_info =
[
    [ "gw", "dc/d6d/struct_pocuter_w_i_f_i_1_1ip_info.html#aaaf1d573045d1f8fc4cc813de2d6f6d4", null ],
    [ "ipV4", "dc/d6d/struct_pocuter_w_i_f_i_1_1ip_info.html#adb2e8ea2f30fad5132044a54c4d4b276", null ],
    [ "netmask", "dc/d6d/struct_pocuter_w_i_f_i_1_1ip_info.html#a679f78fba66ae12ca5de11848dffb0e6", null ]
];
var class_pocuter_accelerometer =
[
    [ "State", "df/db4/struct_pocuter_accelerometer_1_1_state.html", "df/db4/struct_pocuter_accelerometer_1_1_state" ],
    [ "accEventHandler", "df/dad/class_pocuter_accelerometer.html#a0cb327733db4b3ff1193849d8ed70575", null ],
    [ "ACCERROR", "df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951", [
      [ "ACCERROR_OK", "df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951a14897e6a99a017e36cfea62a775cb8f4", null ],
      [ "ACCERROR_OFFLINE", "df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951ad49236e82b6f297cfbe373e055be2e39", null ],
      [ "ACCERROR_COMMUNICATION_FAILED", "df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951a4687e191cc103dea009d685604164d3f", null ],
      [ "ACCERROR_UNKNOWN", "df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951a0c0a96300c2972eb7d310cf362fe891a", null ]
    ] ],
    [ "ACCEVENT", "df/dad/class_pocuter_accelerometer.html#afe467f8f0fa644c6b8366c93e4dbe915", [
      [ "ACC_ORIENTATION", "df/dad/class_pocuter_accelerometer.html#afe467f8f0fa644c6b8366c93e4dbe915aa28f3bf4718f02bb623a3809cc249c31", null ],
      [ "ACC_SHAKE", "df/dad/class_pocuter_accelerometer.html#afe467f8f0fa644c6b8366c93e4dbe915ae899c2f7ef6e49dfc42f8f64b1f3fb1f", null ]
    ] ],
    [ "ACCSCALE", "df/dad/class_pocuter_accelerometer.html#a6c49e0a556ad66e1e7b98deb22bbcec1", [
      [ "G2", "df/dad/class_pocuter_accelerometer.html#a6c49e0a556ad66e1e7b98deb22bbcec1a19c084650693a4a0dc014373ebd97cf7", null ],
      [ "G4", "df/dad/class_pocuter_accelerometer.html#a6c49e0a556ad66e1e7b98deb22bbcec1aff8eecb892728a1924f9adf500406d3b", null ],
      [ "G8", "df/dad/class_pocuter_accelerometer.html#a6c49e0a556ad66e1e7b98deb22bbcec1a23eea4c0645251c790548c815fe8efb8", null ]
    ] ],
    [ "getState", "df/dad/class_pocuter_accelerometer.html#a74caadf5c47dbf0fc185062c6ec8bfa5", null ],
    [ "getTemperature", "df/dad/class_pocuter_accelerometer.html#ad9b3519c5e84abb499314ce80b04b912", null ],
    [ "isOnline", "df/dad/class_pocuter_accelerometer.html#a066e2e6c1804c46b30d9ed8421b87169", null ],
    [ "registerEventHandler", "df/dad/class_pocuter_accelerometer.html#a80c972f6430295acfb9ce98961cff6ac", null ],
    [ "setScale", "df/dad/class_pocuter_accelerometer.html#a1da9066f272562b288d25045df522d65", null ],
    [ "unregisterEventHandler", "df/dad/class_pocuter_accelerometer.html#a5586bf402311d1892db736317dc63aeb", null ]
];
var struct_pocuter_accelerometer_1_1_state =
[
    [ "x", "df/db4/struct_pocuter_accelerometer_1_1_state.html#a31cc484c9b12c5af9ff9aa49cce6a2be", null ],
    [ "y", "df/db4/struct_pocuter_accelerometer_1_1_state.html#a2dcfff67e567192592a081f9d0645ec1", null ],
    [ "z", "df/db4/struct_pocuter_accelerometer_1_1_state.html#a19ab61517909b0b4caedb25011ed1567", null ]
];
var _pocuter_time_8h =
[
    [ "PocuterTime", "d8/dac/class_pocuter_time.html", "d8/dac/class_pocuter_time" ],
    [ "pocuterTimezone", "dc/d6c/struct_pocuter_time_1_1pocuter_timezone.html", "dc/d6c/struct_pocuter_time_1_1pocuter_timezone" ],
    [ "TIME_ZONES_COUNT", "df/d04/_pocuter_time_8h.html#a05b5f2bd02ccd175608c7af471a2a0a8", null ],
    [ "TIME_ZONES_COUNT", "df/d04/_pocuter_time_8h.html#a05b5f2bd02ccd175608c7af471a2a0a8", null ]
];
var searchData=
[
  ['reduction_5flevel_5fhight_477',['REDUCTION_LEVEL_HIGHT',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eab9c3f0edb28268bc99f3df8a6874dc1c',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fmedium_478',['REDUCTION_LEVEL_MEDIUM',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090ea35af993c4995e6d1c65ea3fe3efecf35',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fnone_479',['REDUCTION_LEVEL_NONE',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eafc15430687136edc8feee88102ad0aae',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fraw_480',['REDUCTION_LEVEL_RAW',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eacd72f0c21093c82683d3c9ef4d57f279',1,'PocuterMicrophone']]],
  ['reduction_5flevel_5fsmall_481',['REDUCTION_LEVEL_SMALL',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090ea4c2da3650adb394ae536ef64bfe8bfcc',1,'PocuterMicrophone']]]
];

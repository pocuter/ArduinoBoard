/*
PocketScreen.h
Last modified 07 Oct 2020

This file is part of the PocketScreen Library.

Copyright (C) 2018-2020  Florian Keller

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PocketScreen_h
#define PocketScreen_h

#include <SPI.h>
#include "PS_Colors.h"
#include "PS_Commands.h"
#include "PS_FontDefinitions.h"
#include "PS_Fonts.h"

const uint8_t ColorModeRGB = 0;
const uint8_t ColorModeBGR = 1;

const uint8_t BitDepth8 = 0;
const uint8_t BitDepth16 = 1;

const uint8_t LEDOff = 0;
const uint8_t LEDRed = 1;
const uint8_t LEDGreen = 2;
const uint8_t LEDBlue = 3;

const uint8_t PIN_LED_RED           = 3;    // PA09
const uint8_t PIN_LED_GREEN         = 7;    // PA21
const uint8_t PIN_LED_BLUE          = 20;   // PA22

const uint8_t PIN_BATTERY_LEVEL     = 9;    // PA07
const uint8_t PIN_BATTERY_CHARGING  = 18;   // PA05

const uint8_t PIN_BUTTON_0          = 4;    // PA08
const uint8_t PIN_BUTTON_1          = 5;    // PA15
const uint8_t PIN_BUTTON_2          = 17;   // PA04

const uint8_t PIN_SD_CHECK          = 6;    // PA20

const uint8_t PIN_ESP_ENABLE        = 8;    // PA06

const uint8_t PIN_DC                = 22;   // PA12
const uint8_t PIN_CS                = 38;   // PA13
const uint8_t PIN_SHDN              = 27;   // PA28
const uint8_t PIN_RST               = 26;   // PA27

class PocketScreen : public Print {
  public:
    
    // init
    PocketScreen();
    void begin(void);
    
    // general control
    void startTransfer(void);
    void endTransfer(void);
    void on(void);
    void off(void);
    void setMirror(boolean mirror);
    void setBitDepth(uint8_t bitDepth);
    void setColorMode(uint8_t colorMode);
    void setBrightness(uint8_t brightness);
    
    // accelerated graphics commands
    void clearWindow(uint8_t x, uint8_t y, uint8_t width, uint8_t height);
    void clearScreen(void);
    void drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color);
    void drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint16_t color);
    void drawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t red, uint8_t green, uint8_t blue);
    void drawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, boolean fill, uint8_t color);
    void drawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, boolean fill, uint16_t color);
    void drawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, boolean fill, uint8_t red, uint8_t green, uint8_t blue);
    
    // pixel manipulation
    void drawPixel(uint8_t x, uint8_t y, uint16_t color);
    void setX(uint8_t start, uint8_t end);
    void setY(uint8_t start, uint8_t end);
    void goTo(uint8_t x, uint8_t y);
    void writeBuffer(const uint8_t *buffer, int count);
    void writeBuffer(const uint16_t *buffer, int count);
    
    // printing text
    void setFont(const PSFont &font);
    void setFontColor(uint16_t color, uint16_t colorBackground);
    void setCursor(uint8_t x, uint8_t y);
    uint8_t getPrintWidth(char *text);
    
    // SD check
    boolean isSDInserted();
    
    // battery info
    int batteryLevel();
    boolean isCharging();
    
    // LED
    void setLEDColor(uint8_t color);
    
    // bounds
    static const uint8_t xMax = 95;
    static const uint8_t yMax = 63;
    
  private:
    boolean bitDepth16, colorModeBGR, mirror;
    uint8_t cursorX, cursorY, fontHeight, fontFirstChar, fontLastChar;
    uint16_t fontColor, fontColorBackground;
    const PSCharInfo *fontDescriptor;
    const unsigned char *fontBitmap;
    SPIClass *PocketScreen_SPI;
    
    void startCommandTransfer(void);
    void writeRemap(void);
    virtual size_t write(uint8_t c);
};

#endif
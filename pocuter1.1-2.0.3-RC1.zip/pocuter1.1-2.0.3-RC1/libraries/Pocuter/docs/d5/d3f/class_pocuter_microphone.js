var class_pocuter_microphone =
[
    [ "micEventHandler", "d5/d3f/class_pocuter_microphone.html#a849d7b8400b19109f8ffac8b1ced6e92", null ],
    [ "MICERROR", "d5/d3f/class_pocuter_microphone.html#aa8fba3b3931c5a06e655b03e16058ec8", [
      [ "MICERROR_OK", "d5/d3f/class_pocuter_microphone.html#aa8fba3b3931c5a06e655b03e16058ec8a2db1e08ca7ef133cf65c009901d8243a", null ],
      [ "MICERROR_RESOURCE_NOT_AVAILABLE", "d5/d3f/class_pocuter_microphone.html#aa8fba3b3931c5a06e655b03e16058ec8adc7115fbfdfc1bb74ef606ce999880cb", null ],
      [ "MICERROR_UNKNOWN", "d5/d3f/class_pocuter_microphone.html#aa8fba3b3931c5a06e655b03e16058ec8a517740fe364af962b8d31f8c073c13f8", null ]
    ] ],
    [ "MICEVENT", "d5/d3f/class_pocuter_microphone.html#adb9cef704f6c738da1717cdf4596c975", [
      [ "MIC_DATA_PACKAGE", "d5/d3f/class_pocuter_microphone.html#adb9cef704f6c738da1717cdf4596c975a85eaf6e9106277fa6fdc241586ae6283", null ]
    ] ],
    [ "NOICE_REDUCTION_LEVEL", "d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090e", [
      [ "REDUCTION_LEVEL_NONE", "d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eafc15430687136edc8feee88102ad0aae", null ],
      [ "REDUCTION_LEVEL_SMALL", "d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090ea4c2da3650adb394ae536ef64bfe8bfcc", null ],
      [ "REDUCTION_LEVEL_MEDIUM", "d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090ea35af993c4995e6d1c65ea3fe3efecf35", null ],
      [ "REDUCTION_LEVEL_HIGHT", "d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eab9c3f0edb28268bc99f3df8a6874dc1c", null ],
      [ "REDUCTION_LEVEL_RAW", "d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090eacd72f0c21093c82683d3c9ef4d57f279", null ]
    ] ],
    [ "SAMLE_RATE_HZ", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531", [
      [ "SAMLE_RATE_8000", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531a763a334887709cad769f1339ead7f541", null ],
      [ "SAMLE_RATE_11025", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531ae507a85a80fac9a9e09872e814922b96", null ],
      [ "SAMLE_RATE_16000", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531a0868124a3c82403c8d1216cf736e7920", null ],
      [ "SAMLE_RATE_22050", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531a14c608c8786dd9a6e70b6fd918c6788a", null ],
      [ "SAMLE_RATE_32000", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531a5499899e081c173485e5e4f453026c69", null ],
      [ "SAMLE_RATE_44100", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531a0bf4fe7f14a439ba1eb9500a1c92ca68", null ],
      [ "SAMLE_RATE_48000", "d5/d3f/class_pocuter_microphone.html#a129e0cb548be57c7e9719d3f0a79f531a65c099b7d12e040d08d4a102b9624222", null ]
    ] ],
    [ "registerEventHandler", "d5/d3f/class_pocuter_microphone.html#aae1bc783759a21dc821e1a4c4c66a119", null ],
    [ "startRecording", "d5/d3f/class_pocuter_microphone.html#a0a3ccc14d4bd6efd00fa8efe9cdd6cf3", null ],
    [ "stopRecording", "d5/d3f/class_pocuter_microphone.html#ac0097a842461a6fe7dd2138541deb88d", null ],
    [ "unregisterEventHandler", "d5/d3f/class_pocuter_microphone.html#ad6a4d41a828a67c4a7f0f4dbe31b3422", null ]
];
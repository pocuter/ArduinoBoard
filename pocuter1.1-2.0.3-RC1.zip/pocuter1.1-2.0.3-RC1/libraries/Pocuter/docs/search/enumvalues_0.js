var searchData=
[
  ['acc_5forientation_475',['ACC_ORIENTATION',['../df/dad/class_pocuter_accelerometer.html#afe467f8f0fa644c6b8366c93e4dbe915aa28f3bf4718f02bb623a3809cc249c31',1,'PocuterAccelerometer']]],
  ['acc_5fshake_476',['ACC_SHAKE',['../df/dad/class_pocuter_accelerometer.html#afe467f8f0fa644c6b8366c93e4dbe915ae899c2f7ef6e49dfc42f8f64b1f3fb1f',1,'PocuterAccelerometer']]],
  ['accerror_5fcommunication_5ffailed_477',['ACCERROR_COMMUNICATION_FAILED',['../df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951a4687e191cc103dea009d685604164d3f',1,'PocuterAccelerometer']]],
  ['accerror_5foffline_478',['ACCERROR_OFFLINE',['../df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951ad49236e82b6f297cfbe373e055be2e39',1,'PocuterAccelerometer']]],
  ['accerror_5fok_479',['ACCERROR_OK',['../df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951a14897e6a99a017e36cfea62a775cb8f4',1,'PocuterAccelerometer']]],
  ['accerror_5funknown_480',['ACCERROR_UNKNOWN',['../df/dad/class_pocuter_accelerometer.html#a6f8f1c1eba16607e472b513a6b4db951a0c0a96300c2972eb7d310cf362fe891a',1,'PocuterAccelerometer']]]
];

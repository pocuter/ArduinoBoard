var searchData=
[
  ['verifypartition_247',['verifyPartition',['../d0/d1f/class_pocuter_o_t_a.html#a7c089b9d31ca5914e6d4ab42a7c196ae',1,'PocuterOTA']]]
];

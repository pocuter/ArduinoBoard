var searchData=
[
  ['noice_5freduction_5flevel_460',['NOICE_REDUCTION_LEVEL',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090e',1,'PocuterMicrophone']]]
];

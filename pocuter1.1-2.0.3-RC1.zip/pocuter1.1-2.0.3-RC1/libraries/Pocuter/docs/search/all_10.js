var searchData=
[
  ['ugui_244',['ugui',['../d2/dca/class_pocuter.html#aff01cd59cd2540da4e19916896b57ff3',1,'Pocuter']]],
  ['unregistereventhandler_245',['unregisterEventHandler',['../df/dad/class_pocuter_accelerometer.html#a5586bf402311d1892db736317dc63aeb',1,'PocuterAccelerometer::unregisterEventHandler()'],['../df/d44/class_pocuter_buttons.html#a3c06f58e7a0323ad75786aad36bff65f',1,'PocuterButtons::unregisterEventHandler()'],['../d1/d48/class_pocuter_light_sensor.html#ae84478425d18568cabf5cabbf2f6204c',1,'PocuterLightSensor::unregisterEventHandler()'],['../d5/d3f/class_pocuter_microphone.html#ad6a4d41a828a67c4a7f0f4dbe31b3422',1,'PocuterMicrophone::unregisterEventHandler()']]],
  ['updatescreen_246',['updateScreen',['../dd/d08/class_pocuter_display.html#a79c629c35320c2e4147bfaac8741484c',1,'PocuterDisplay']]]
];

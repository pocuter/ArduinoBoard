var searchData=
[
  ['lederror_5ffailure_496',['LEDERROR_FAILURE',['../d6/d2a/class_r_g_bled.html#a97dcd675f2fec2253b0d138ab90db786a854ff54147c20f65ce9a79dd6a9021df',1,'RGBled']]],
  ['lederror_5fok_497',['LEDERROR_OK',['../d6/d2a/class_r_g_bled.html#a97dcd675f2fec2253b0d138ab90db786ab7cbf06137fa6b1de6035e0323d1e1fe',1,'RGBled']]],
  ['light_5fabove_5flimit_498',['LIGHT_ABOVE_LIMIT',['../d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfeaffcb7da3eff7f2c5710e3b6e1c4769d2',1,'PocuterLightSensor']]],
  ['light_5ftollerance_5fchanged_499',['LIGHT_TOLLERANCE_CHANGED',['../d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfeadfe213d8eba2d36dbf7955e754727b35',1,'PocuterLightSensor']]],
  ['light_5funder_5flimit_500',['LIGHT_UNDER_LIMIT',['../d1/d48/class_pocuter_light_sensor.html#ac6c79457465e286d42e00a0052a6abfea7caf907a1e44c7a9e4e3d512391b016d',1,'PocuterLightSensor']]],
  ['lighterror_5fok_501',['LIGHTERROR_OK',['../d1/d48/class_pocuter_light_sensor.html#a315729d520e84c8ec341e3425ca553e1a28a56673a5e3a701a59fb4077eb39e2f',1,'PocuterLightSensor']]],
  ['lighterror_5funknown_502',['LIGHTERROR_UNKNOWN',['../d1/d48/class_pocuter_light_sensor.html#a315729d520e84c8ec341e3425ca553e1a76aca07fae1b242744945543dbabe082',1,'PocuterLightSensor']]]
];

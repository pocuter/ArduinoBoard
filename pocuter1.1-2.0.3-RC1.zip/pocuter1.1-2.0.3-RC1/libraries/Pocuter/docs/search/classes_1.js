var searchData=
[
  ['ipinfo_290',['ipInfo',['../dc/d6d/struct_pocuter_w_i_f_i_1_1ip_info.html',1,'PocuterWIFI']]]
];

var searchData=
[
  ['otaerror_5fapp_5fread_5ferror_507',['OTAERROR_APP_READ_ERROR',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3ae96ceeeadcb826f8eb4d12d3ad708dd4',1,'PocuterOTA']]],
  ['otaerror_5ffile_5fnot_5ffound_508',['OTAERROR_FILE_NOT_FOUND',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a43244cfe27277cfc0a7e0bc72662b29e',1,'PocuterOTA']]],
  ['otaerror_5fflashing_5ffailed_509',['OTAERROR_FLASHING_FAILED',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a61008c290cf00ffeb8777193107a8bb6',1,'PocuterOTA']]],
  ['otaerror_5fmore_5fsteps_510',['OTAERROR_MORE_STEPS',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a25d73d94553e4a90e9f6ee3f3a45ba11',1,'PocuterOTA']]],
  ['otaerror_5fno_5fsd_5fcard_511',['OTAERROR_NO_SD_CARD',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3adde1743b8ebd0b0ab790fc54ef0bc628',1,'PocuterOTA']]],
  ['otaerror_5fok_512',['OTAERROR_OK',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a0aa619870c61151066abffa02062b47f',1,'PocuterOTA']]],
  ['otaerror_5fpatition_5fin_5fuse_513',['OTAERROR_PATITION_IN_USE',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3ab96f3af3dddf616fbf7c2757e9671ad4',1,'PocuterOTA']]],
  ['otaerror_5fpatition_5fnot_5favailable_514',['OTAERROR_PATITION_NOT_AVAILABLE',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3a2a1fe0754747708105124a044635ec94',1,'PocuterOTA']]],
  ['otaerror_5funknown_515',['OTAERROR_UNKNOWN',['../d0/d1f/class_pocuter_o_t_a.html#a6112a2e8934301ecec3257b2edbe9cb3ade1731d4e4c8092c07d571c4eeacf5eb',1,'PocuterOTA']]]
];

var searchData=
[
  ['name_119',['name',['../dc/d6c/struct_pocuter_time_1_1pocuter_timezone.html#a9204b4a72075e715cb6e87199d6e4a99',1,'PocuterTime::pocuterTimezone']]],
  ['netmask_120',['netmask',['../dc/d6d/struct_pocuter_w_i_f_i_1_1ip_info.html#a679f78fba66ae12ca5de11848dffb0e6',1,'PocuterWIFI::ipInfo']]],
  ['noice_5freduction_5flevel_121',['NOICE_REDUCTION_LEVEL',['../d5/d3f/class_pocuter_microphone.html#a47f5dcd58280ef8b4bca00f61330090e',1,'PocuterMicrophone']]]
];
